
import { Category, Compliment } from './types';

export const CATEGORIES: Category[] = [
  Category.Friend,
  Category.Teacher,
  Category.Colleague,
  Category.General,
];

export const INITIAL_COMPLIMENTS: Compliment[] = [
  {
    id: 1,
    text: "To the person who always smiles in class — you make everyone’s day brighter!",
    category: Category.General,
    likes: 12,
  },
  {
    id: 2,
    text: "Your presentation today was so insightful. You have a real talent for explaining complex topics.",
    category: Category.Colleague,
    likes: 8,
  },
  {
    id: 3,
    text: "Thank you for being such a patient and understanding teacher. You make learning fun.",
    category: Category.Teacher,
    likes: 25,
  },
  {
    id: 4,
    text: "I really appreciate how you always listen and give the best advice. You're a wonderful friend.",
    category: Category.Friend,
    likes: 18,
  },
  {
    id: 5,
    text: "The way you organize our team projects is amazing. You keep everything running smoothly!",
    category: Category.Colleague,
    likes: 15,
  },
  {
    id: 6,
    text: "Your positive attitude is contagious. Thank you for bringing so much energy to the room.",
    category: Category.General,
    likes: 31,
  },
   {
    id: 7,
    text: "Just wanted to say you have a great sense of style. Your outfits are always on point!",
    category: Category.General,
    likes: 7,
  },
  {
    id: 8,
    text: "I'm so grateful for our friendship. You've been there for me through thick and thin.",
    category: Category.Friend,
    likes: 22,
  }
];
