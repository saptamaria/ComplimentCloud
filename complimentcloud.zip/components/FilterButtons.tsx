
import React from 'react';
import { Category } from '../types';

interface FilterButtonsProps {
  categories: Category[];
  activeFilter: Category | 'All';
  onFilterChange: (filter: Category | 'All') => void;
}

const FilterButtons: React.FC<FilterButtonsProps> = ({ categories, activeFilter, onFilterChange }) => {
  const allCategories: (Category | 'All')[] = ['All', ...categories];

  return (
    <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-8">
      {allCategories.map(filter => {
        const isActive = activeFilter === filter;
        return (
          <button
            key={filter}
            onClick={() => onFilterChange(filter)}
            className={`px-4 py-2 text-sm sm:text-base font-semibold rounded-full transition-all duration-300 ${
              isActive
                ? 'bg-sky-500 text-white shadow-md'
                : 'bg-white text-gray-600 hover:bg-sky-100 hover:text-sky-700'
            }`}
          >
            {filter}
          </button>
        );
      })}
    </div>
  );
};

export default FilterButtons;
