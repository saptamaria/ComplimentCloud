
import React, { useState } from 'react';
import { Category } from '../types';
import { SendIcon } from './IconComponents';

interface ComplimentFormProps {
  categories: Category[];
  onAddCompliment: (text: string, category: Category) => void;
}

const ComplimentForm: React.FC<ComplimentFormProps> = ({ categories, onAddCompliment }) => {
  const [text, setText] = useState('');
  const [category, setCategory] = useState<Category>(categories[0]);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim().length < 10) {
      setError('Your compliment needs to be at least 10 characters long.');
      return;
    }
    if (text.trim().length > 280) {
      setError('Your compliment must be 280 characters or less.');
      return;
    }

    onAddCompliment(text, category);
    setText('');
    setError('');
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg mb-8">
      <form onSubmit={handleSubmit} className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-700">Share a kind word...</h2>
        <div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Example: 'To the person who always smiles in class — you make everyone’s day brighter!'"
            className="w-full h-28 p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-sky-400 focus:border-sky-400 transition-shadow duration-200 resize-none"
            maxLength={280}
          />
          <p className="text-right text-sm text-gray-400 mt-1">{text.length}/280</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as Category)}
            className="w-full sm:w-auto p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-sky-400 focus:border-sky-400 transition"
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <button
            type="submit"
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-sky-500 text-white font-semibold px-6 py-2 rounded-full shadow-md hover:bg-sky-600 transition-all duration-300 transform hover:scale-105"
          >
            <SendIcon />
            <span>Post Anonymously</span>
          </button>
        </div>
        {error && <p className="text-rose-500 text-sm mt-2">{error}</p>}
      </form>
    </div>
  );
};

export default ComplimentForm;
