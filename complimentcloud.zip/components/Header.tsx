
import React from 'react';
import { SparklesIcon } from './IconComponents';

interface HeaderProps {
  onSurpriseMe: () => void;
}

const Header: React.FC<HeaderProps> = ({ onSurpriseMe }) => {
  return (
    <header className="bg-white/80 backdrop-blur-lg sticky top-0 z-40 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-500 to-rose-500">
          ComplimentCloud 🌸
        </h1>
        <button
          onClick={onSurpriseMe}
          className="flex items-center gap-2 bg-rose-500 text-white font-semibold px-4 py-2 rounded-full shadow-md hover:bg-rose-600 transition-all duration-300 transform hover:scale-105 active:scale-100"
        >
          <SparklesIcon />
          <span>Surprise Me</span>
        </button>
      </div>
    </header>
  );
};

export default Header;
