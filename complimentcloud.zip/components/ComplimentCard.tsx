
import React from 'react';
import { Compliment, Category } from '../types';
import { HeartIcon } from './IconComponents';

interface ComplimentCardProps {
  compliment: Compliment;
  onLike: (id: number) => void;
}

const categoryColors: { [key in Category]: { bg: string; text: string; tagBg: string } } = {
  [Category.Friend]: { bg: 'bg-yellow-100', text: 'text-yellow-800', tagBg: 'bg-yellow-200' },
  [Category.Teacher]: { bg: 'bg-blue-100', text: 'text-blue-800', tagBg: 'bg-blue-200' },
  [Category.Colleague]: { bg: 'bg-green-100', text: 'text-green-800', tagBg: 'bg-green-200' },
  [Category.General]: { bg: 'bg-rose-100', text: 'text-rose-800', tagBg: 'bg-rose-200' },
};

const ComplimentCard: React.FC<ComplimentCardProps> = ({ compliment, onLike }) => {
  const colors = categoryColors[compliment.category] || categoryColors[Category.General];

  return (
    <div
      className={`relative p-6 rounded-2xl shadow-sm hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-1 ${colors.bg} ${colors.text}`}
    >
      <p className="text-lg leading-relaxed mb-4">"{compliment.text}"</p>
      <div className="flex justify-between items-center">
        <span className={`px-3 py-1 text-sm font-medium rounded-full ${colors.tagBg}`}>
          {compliment.category}
        </span>
        <button
          onClick={() => onLike(compliment.id)}
          className="flex items-center gap-2 text-rose-500 hover:text-rose-600 group transition-colors"
        >
          <HeartIcon />
          <span className="font-semibold group-hover:underline">{compliment.likes}</span>
        </button>
      </div>
    </div>
  );
};

export default ComplimentCard;
