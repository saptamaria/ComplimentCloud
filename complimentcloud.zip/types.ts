
export enum Category {
  Friend = 'Friend',
  Teacher = 'Teacher',
  Colleague = 'Colleague',
  General = 'General Positivity',
}

export interface Compliment {
  id: number;
  text: string;
  category: Category;
  likes: number;
}
