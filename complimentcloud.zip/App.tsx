
import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import ComplimentForm from './components/ComplimentForm';
import FilterButtons from './components/FilterButtons';
import ComplimentCard from './components/ComplimentCard';
import { Category, Compliment } from './types';
import { CATEGORIES, INITIAL_COMPLIMENTS } from './constants';
import { CloseIcon } from './components/IconComponents';

function App() {
  const [compliments, setCompliments] = useState<Compliment[]>(INITIAL_COMPLIMENTS);
  const [activeFilter, setActiveFilter] = useState<Category | 'All'>('All');
  const [randomCompliment, setRandomCompliment] = useState<Compliment | null>(null);

  const handleAddCompliment = (text: string, category: Category) => {
    const newCompliment: Compliment = {
      id: Date.now(),
      text,
      category,
      likes: 0,
    };
    setCompliments(prev => [newCompliment, ...prev]);
  };

  const handleLike = (id: number) => {
    setCompliments(prev =>
      prev.map(c => (c.id === id ? { ...c, likes: c.likes + 1 } : c))
    );
  };

  const handleShowRandom = () => {
    if (compliments.length > 0) {
      const randomIndex = Math.floor(Math.random() * compliments.length);
      setRandomCompliment(compliments[randomIndex]);
    }
  };

  const handleCloseModal = () => {
    setRandomCompliment(null);
  };

  const filteredCompliments = useMemo(() => {
    if (activeFilter === 'All') {
      return compliments;
    }
    return compliments.filter(c => c.category === activeFilter);
  }, [compliments, activeFilter]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-rose-50 text-gray-800">
      <Header onSurpriseMe={handleShowRandom} />
      <main className="container mx-auto px-4 py-8">
        <ComplimentForm categories={CATEGORIES} onAddCompliment={handleAddCompliment} />
        <FilterButtons
          categories={CATEGORIES}
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
        />
        
        <div className="mt-8">
          {filteredCompliments.length > 0 ? (
            <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
              {filteredCompliments.map(compliment => (
                <div key={compliment.id} className="break-inside-avoid">
                  <ComplimentCard
                    compliment={compliment}
                    onLike={handleLike}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 px-6 bg-white/60 rounded-2xl shadow-sm">
              <p className="text-xl text-gray-500">No compliments found for this category.</p>
              <p className="mt-2 text-gray-400">Why not be the first to add one?</p>
            </div>
          )}
        </div>
      </main>

      {randomCompliment && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
          onClick={handleCloseModal}
        >
          <div 
            className="relative bg-white rounded-2xl p-8 shadow-2xl max-w-lg w-full transform transition-all duration-300 scale-95 animate-fade-in-up"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={handleCloseModal}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
              aria-label="Close"
            >
             <CloseIcon />
            </button>
            <h3 className="text-lg font-semibold text-rose-500 mb-4">A little positivity for you...</h3>
            <p className="text-xl text-gray-700 leading-relaxed">"{randomCompliment.text}"</p>
          </div>
        </div>
      )}
      <style jsx="true">{`
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(20px) scale(0.95); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
}

export default App;
