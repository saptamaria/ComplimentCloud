import { formatDate } from '../utils/helpers';

const ComplimentCard = ({ compliment }) => {

  return (
    <div className="compliment-card">
      <div className="compliment-header">
        <div className="compliment-name">
          {compliment.name || 'Anonymous'} ✨
        </div>
        <div className="compliment-time">
          {formatDate(compliment.createdAt)}
        </div>
      </div>
      <div className="compliment-message">
        "{compliment.message}"
      </div>
    </div>
  );
};

export default ComplimentCard;
