import { useState } from 'react';
import { validateCompliment, getRandomPlaceholder } from '../utils/helpers';

const ComplimentForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState({ type: '', message: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear feedback when user starts typing
    if (feedback.message) {
      setFeedback({ type: '', message: '' });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate input
    const validation = validateCompliment(formData);
    if (!validation.isValid) {
      setFeedback({ type: 'error', message: Object.values(validation.errors)[0] });
      return;
    }

    setIsSubmitting(true);
    const result = await onSubmit(formData);
    
    if (result.success) {
      setFormData({ name: '', message: '' });
      setFeedback({ type: 'success', message: 'Your compliment has been added to the wall! 🎉' });
      // Clear success message after 3 seconds
      setTimeout(() => {
        setFeedback({ type: '', message: '' });
      }, 3000);
    } else {
      setFeedback({ type: 'error', message: result.error });
    }
    
    setIsSubmitting(false);
  };

  return (
    <div className="form-container">
      <h2 style={{ marginBottom: '20px', color: '#333' }}>Share a Compliment</h2>
      
      {feedback.message && (
        <div className={feedback.type === 'error' ? 'error' : 'success'}>
          {feedback.message}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Your Name (Optional)</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter your name or leave blank for Anonymous"
            maxLength={50}
          />
        </div>

        <div className="form-group">
          <label htmlFor="message">Compliment Message *</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder={getRandomPlaceholder()}
            required
            maxLength={500}
          />
          <small style={{ color: '#888', fontSize: '0.8rem' }}>
            {formData.message.length}/500 characters
          </small>
        </div>

        <button 
          type="submit" 
          className="submit-btn"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Posting...' : '💝 Post Compliment'}
        </button>
      </form>
    </div>
  );
};

export default ComplimentForm;
