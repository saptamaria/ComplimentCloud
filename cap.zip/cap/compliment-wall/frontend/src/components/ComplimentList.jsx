import ComplimentCard from './ComplimentCard';

const ComplimentList = ({ compliments }) => {
  if (!compliments || compliments.length === 0) {
    return (
      <div className="empty-state">
        <h3>No compliments yet! 🌟</h3>
        <p>Be the first to spread some kindness!</p>
      </div>
    );
  }

  return (
    <div className="compliments-container">
      <h2 style={{ color: 'white', marginBottom: '20px', textAlign: 'center' }}>
        Recent Compliments ({compliments.length})
      </h2>
      {compliments.map((compliment) => (
        <ComplimentCard 
          key={compliment._id} 
          compliment={compliment} 
        />
      ))}
    </div>
  );
};

export default ComplimentList;
