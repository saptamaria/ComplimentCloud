import { useState, useEffect } from 'react';
import ComplimentForm from './components/ComplimentForm';
import ComplimentList from './components/ComplimentList';
import { complimentAPI } from './utils/api';

function App() {
  const [compliments, setCompliments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Fetch compliments from the API
  const fetchCompliments = async () => {
    try {
      setLoading(true);
      const response = await complimentAPI.getAllCompliments();
      if (response.success) {
        setCompliments(response.data);
      }
      setError('');
    } catch (err) {
      console.error('Error fetching compliments:', err);
      setError(err.message || 'Failed to load compliments. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  // Handle new compliment submission
  const handleComplimentSubmit = async (complimentData) => {
    try {
      const response = await complimentAPI.createCompliment(complimentData);
      if (response.success) {
        // Add the new compliment to the beginning of the list
        setCompliments(prevCompliments => [response.data, ...prevCompliments]);
        return { success: true };
      }
    } catch (err) {
      console.error('Error submitting compliment:', err);
      return { 
        success: false, 
        error: err.message || 'Failed to submit compliment. Please try again.' 
      };
    }
  };

  // Load compliments on component mount
  useEffect(() => {
    fetchCompliments();
  }, []);

  return (
    <div className="container">
      <header className="header">
        <h1>💝 Compliment Wall</h1>
        <p>Spread kindness, one compliment at a time!</p>
      </header>

      <ComplimentForm onSubmit={handleComplimentSubmit} />

      {error && (
        <div className="error">
          {error}
          <button 
            onClick={fetchCompliments}
            style={{ marginLeft: '10px', padding: '5px 10px', cursor: 'pointer' }}
          >
            Retry
          </button>
        </div>
      )}

      {loading ? (
        <div className="loading">Loading compliments...</div>
      ) : (
        <ComplimentList compliments={compliments} />
      )}
    </div>
  );
}

export default App;
