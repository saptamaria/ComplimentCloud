import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Create axios instance with default config
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    console.log(`Making ${config.method?.toUpperCase()} request to ${config.url}`);
    return config;
  },
  (error) => {
    console.error('Request error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => {
    console.log(`Response received:`, response.status);
    return response;
  },
  (error) => {
    console.error('Response error:', error);
    
    if (error.code === 'ECONNABORTED') {
      error.message = 'Request timeout. Please try again.';
    } else if (error.code === 'ERR_NETWORK') {
      error.message = 'Network error. Please check if the backend server is running.';
    } else if (!error.response) {
      error.message = 'Unable to connect to server. Please try again later.';
    }
    
    return Promise.reject(error);
  }
);

// API functions
export const complimentAPI = {
  // Get all compliments
  getAllCompliments: async () => {
    try {
      const response = await api.get('/compliments');
      return response.data;
    } catch (error) {
      throw new Error(error.message || 'Failed to fetch compliments');
    }
  },

  // Create a new compliment
  createCompliment: async (complimentData) => {
    try {
      const response = await api.post('/compliments', complimentData);
      return response.data;
    } catch (error) {
      const message = error.response?.data?.message || error.message || 'Failed to create compliment';
      throw new Error(message);
    }
  },

  // Health check
  healthCheck: async () => {
    try {
      const response = await api.get('/');
      return response.data;
    } catch (error) {
      throw new Error('Backend server is not responding');
    }
  }
};

export default api;
