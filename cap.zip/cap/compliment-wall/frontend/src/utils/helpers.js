// Date formatting utilities
export const formatDate = (dateString) => {
  const date = new Date(dateString);
  const now = new Date();
  const diffInMinutes = Math.floor((now - date) / (1000 * 60));
  
  if (diffInMinutes < 1) {
    return 'Just now';
  } else if (diffInMinutes < 60) {
    return `${diffInMinutes} minute${diffInMinutes > 1 ? 's' : ''} ago`;
  } else if (diffInMinutes < 1440) { // Less than 24 hours
    const hours = Math.floor(diffInMinutes / 60);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  } else if (diffInMinutes < 10080) { // Less than a week
    const days = Math.floor(diffInMinutes / 1440);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  } else {
    // For older dates, show the actual date
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }
};

// Format date for display
export const formatFullDate = (dateString) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

// Input validation utilities
export const validateCompliment = (data) => {
  const errors = {};
  
  if (!data.message || data.message.trim().length === 0) {
    errors.message = 'Message is required';
  } else if (data.message.trim().length < 2) {
    errors.message = 'Message must be at least 2 characters long';
  } else if (data.message.length > 500) {
    errors.message = 'Message cannot exceed 500 characters';
  }
  
  if (data.name && data.name.length > 50) {
    errors.name = 'Name cannot exceed 50 characters';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Text utilities
export const truncateText = (text, maxLength) => {
  if (text.length <= maxLength) return text;
  return text.substr(0, maxLength) + '...';
};

// Random compliment placeholders
export const getRandomPlaceholder = () => {
  const placeholders = [
    "You make the world a better place just by being in it! ✨",
    "Your kindness is like sunshine on a cloudy day! 🌟",
    "You have the most amazing energy that lights up every room! 💫",
    "Your smile is contagious and brightens everyone's day! 😊",
    "You're incredibly thoughtful and caring! 💝",
    "Your positive attitude is truly inspiring! 🚀",
    "You have such a beautiful heart! ❤️",
    "You're stronger than you know and more loved than you realize! 💪"
  ];
  
  return placeholders[Math.floor(Math.random() * placeholders.length)];
};

// Local storage utilities
export const storage = {
  get: (key, defaultValue = null) => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return defaultValue;
    }
  },
  
  set: (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Error writing to localStorage:', error);
    }
  },
  
  remove: (key) => {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Error removing from localStorage:', error);
    }
  }
};
