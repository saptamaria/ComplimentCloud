# 🚀 Setup Instructions for Compliment Wall

## Prerequisites Installation

### 1. Install Node.js and npm
1. Go to https://nodejs.org/
2. Download the LTS version (recommended)
3. Run the installer and follow the setup wizard
4. Restart your terminal/command prompt after installation

### 2. Install MongoDB (Choose one option)

**Option A: MongoDB Atlas (Cloud - Recommended for beginners)**
1. Go to https://www.mongodb.com/atlas
2. Create a free account
3. Create a new cluster
4. Get your connection string
5. Update the `backend/.env` file with your MongoDB Atlas connection string

**Option B: Local MongoDB Installation**
1. Go to https://www.mongodb.com/try/download/community
2. Download and install MongoDB Community Server
3. Follow the installation guide for your operating system
4. Start MongoDB service

## 🎯 Quick Start Guide

### Step 1: Verify Installation
Open a new terminal/command prompt and run:
```bash
node --version
npm --version
```
You should see version numbers for both commands.

### Step 2: Install Dependencies
From the project root directory:

**Windows PowerShell:**
```powershell
cd "c:\Users\Student\Desktop\cap\compliment-wall"
cd backend; npm install; cd ../frontend; npm install; cd ..
```

**Windows Command Prompt:**
```cmd
cd "c:\Users\Student\Desktop\cap\compliment-wall"
cd backend && npm install && cd ../frontend && npm install && cd ..
```

### Step 3: Configure Environment
1. Open `backend/.env` file
2. Update the MongoDB connection string if needed:
   - For local MongoDB: `mongodb://localhost:27017/compliment-wall`
   - For MongoDB Atlas: Use your cluster connection string

### Step 4: Start the Application

**Option 1: Start both servers in separate terminals**

Terminal 1 (Backend):
```bash
cd backend
npm run dev
```

Terminal 2 (Frontend):
```bash
cd frontend
npm run dev
```

**Option 2: Alternative method**
```bash
# Start backend (keep this terminal open)
cd backend
npm run dev

# In a new terminal, start frontend
cd frontend  
npm run dev
```

### Step 5: Access the Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

## 🔧 Troubleshooting

### Common Issues:

1. **"npm not found" error**
   - Node.js is not installed or not in PATH
   - Restart terminal after Node.js installation

2. **MongoDB connection errors**
   - Check if MongoDB is running (for local installation)
   - Verify connection string in `.env` file
   - For Atlas: Check network access and credentials

3. **Port already in use**
   - Close other applications using ports 3000 or 5000
   - Or modify ports in the configuration files

4. **CORS errors**
   - Make sure backend is running on port 5000
   - Check the proxy configuration in `frontend/vite.config.js`

## 📱 Testing the Application

1. Open http://localhost:3000 in your browser
2. Try posting a compliment (with or without a name)
3. Verify it appears on the wall immediately
4. Test the form validation by submitting empty messages
5. Check the responsive design on different screen sizes

## 🎉 Success Indicators

You'll know everything is working when:
- ✅ Both terminals show servers running without errors
- ✅ Frontend loads at http://localhost:3000
- ✅ You can submit and see compliments
- ✅ Form validation works properly
- ✅ Timestamps display correctly

## 🔄 Development Workflow

After initial setup, for daily development:
1. Start MongoDB (if using local installation)
2. Run `npm run dev` in the backend folder
3. Run `npm run dev` in the frontend folder
4. Start coding! Changes will auto-reload.

## 🚀 Production Deployment Tips

1. **Environment Variables**: Set production MongoDB URI
2. **Build Frontend**: Run `npm run build` in frontend folder
3. **Serve Static Files**: Configure Express to serve built React app
4. **Use Process Manager**: Use PM2 or similar for production Node.js apps
