# Compliment Wall - MERN Stack Application

A beautiful, responsive web application where users can post and view anonymous compliments on a public wall.

## 🚀 Features

- **Anonymous Compliments**: Users can post compliments with optional names
- **Real-time Updates**: New compliments appear instantly
- **Responsive Design**: Beautiful UI that works on all devices
- **MongoDB Persistence**: All compliments are stored permanently
- **Input Validation**: Both frontend and backend validation
- **Error Handling**: Graceful error handling with user feedback

## 🛠️ Tech Stack

- **Frontend**: React.js (Vite), Axios, CSS3
- **Backend**: Node.js, Express.js, MongoDB, Mongoose
- **Database**: MongoDB (local or Atlas)

## 📁 Project Structure

```
compliment-wall/
├── backend/
│   ├── models/
│   │   └── Compliment.js
│   ├── routes/
│   │   └── compliments.js
│   ├── .env
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ComplimentCard.jsx
│   │   │   ├── ComplimentForm.jsx
│   │   │   └── ComplimentList.jsx
│   │   ├── App.jsx
│   │   ├── index.css
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
└── README.md
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local installation or MongoDB Atlas account)

### Installation & Setup

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd compliment-wall
   ```

2. **Backend Setup**
   ```bash
   cd backend
   npm install
   ```

3. **Frontend Setup**
   ```bash
   cd ../frontend
   npm install
   ```

4. **Environment Configuration**
   - Update the `.env` file in the backend folder:
   ```
   MONGODB_URI=mongodb://localhost:27017/compliment-wall
   PORT=5000
   ```
   - For MongoDB Atlas, replace with your connection string

5. **Start the Application**
   
   **Option 1: Start both servers separately**
   ```bash
   # Terminal 1 - Backend
   cd backend
   npm run dev

   # Terminal 2 - Frontend
   cd frontend
   npm run dev
   ```

   **Option 2: Use the provided scripts**
   ```bash
   # From root directory
   npm run dev:backend    # Start backend only
   npm run dev:frontend   # Start frontend only
   npm run dev           # Start both concurrently
   ```

6. **Access the Application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000

## 🔌 API Endpoints

- `GET /api/compliments` - Fetch all compliments
- `POST /api/compliments` - Create a new compliment

### Example API Usage

**Create a compliment:**
```javascript
POST /api/compliments
Content-Type: application/json

{
  "name": "John Doe",
  "message": "You're amazing and make everyone around you better!"
}
```

**Response:**
```javascript
{
  "success": true,
  "message": "Compliment created successfully",
  "data": {
    "_id": "...",
    "name": "John Doe",
    "message": "You're amazing and make everyone around you better!",
    "createdAt": "2025-10-27T..."
  }
}
```

## 🎨 Features Details

### Frontend Components
- **ComplimentForm**: Handles user input and form submission
- **ComplimentList**: Displays all compliments in a grid layout
- **ComplimentCard**: Individual compliment display with name, message, and timestamp

### Backend Features
- **Express Server**: RESTful API with CORS enabled
- **MongoDB Integration**: Mongoose ODM for data modeling
- **Input Validation**: Server-side validation with error handling
- **Error Handling**: Comprehensive error responses

## 🔧 Customization

### Styling
The application uses custom CSS with a gradient background and card-based layout. You can modify the styles in `frontend/src/index.css`.

### Database Schema
The compliment schema can be extended in `backend/models/Compliment.js`:
```javascript
{
  name: { type: String, default: "Anonymous" },
  message: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
}
```

## 🚀 Deployment

### Backend Deployment (Heroku/Railway/etc.)
1. Set environment variables in your hosting platform
2. Ensure MongoDB connection string is configured
3. Deploy the backend folder

### Frontend Deployment (Netlify/Vercel/etc.)
1. Build the frontend: `npm run build`
2. Update API base URL in `App.jsx` to your backend URL
3. Deploy the `dist` folder

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License.

## 🌟 Acknowledgments

- Built with ❤️ using the MERN stack
- Designed to spread positivity and kindness
