const mongoose = require('mongoose');
const Compliment = require('./models/Compliment');

// Test data
const sampleCompliments = [
  {
    name: 'Sarah',
    message: 'You have such a positive energy that lights up every room you enter! Keep being amazing! ✨'
  },
  {
    name: 'Anonymous',
    message: 'Your kindness and compassion inspire everyone around you. Thank you for being you! 💝'
  },
  {
    name: 'Mike',
    message: 'You have an incredible ability to make people feel valued and heard. That\'s a rare gift! 🌟'
  },
  {
    message: 'Your smile can brighten anyone\'s day. Never stop spreading that joy! 😊💫'
  },
  {
    name: 'Emma',
    message: 'You approach challenges with such grace and determination. You\'re truly inspiring! 🚀'
  }
];

async function seedDatabase() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/compliment-wall');
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await Compliment.deleteMany({});
    console.log('🧹 Cleared existing compliments');

    // Insert sample data
    const results = await Compliment.insertMany(sampleCompliments);
    console.log(`✅ Inserted ${results.length} sample compliments`);

    // Display inserted data
    console.log('\n📝 Sample compliments added:');
    results.forEach((compliment, index) => {
      console.log(`${index + 1}. "${compliment.message}" - ${compliment.name}`);
    });

    await mongoose.connection.close();
    console.log('\n✅ Database seeding completed successfully!');
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

// Run the seeding function
if (require.main === module) {
  require('dotenv').config();
  seedDatabase();
}

module.exports = { seedDatabase, sampleCompliments };
