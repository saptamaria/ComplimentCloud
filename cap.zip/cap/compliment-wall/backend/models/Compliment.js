const mongoose = require('mongoose');

const complimentSchema = new mongoose.Schema({
  name: {
    type: String,
    default: 'Anonymous',
    trim: true,
    maxlength: 50
  },
  message: {
    type: String,
    required: [true, 'Message is required'],
    trim: true,
    minlength: [1, 'Message cannot be empty'],
    maxlength: [500, 'Message cannot exceed 500 characters']
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Compliment', complimentSchema);
