// Simple API test using native Node.js HTTP
const http = require('http');

const API_BASE = 'http://localhost:5000';

function makeRequest(options, data = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        try {
          const jsonBody = JSON.parse(body);
          resolve({ status: res.statusCode, data: jsonBody });
        } catch {
          resolve({ status: res.statusCode, data: body });
        }
      });
    });

    req.on('error', reject);
    
    if (data) {
      req.write(JSON.stringify(data));
    }
    
    req.end();
  });
}

async function testAPI() {
  console.log('🧪 Testing Compliment Wall API...\n');

  try {
    // Test 1: Health check
    console.log('1. Testing health check endpoint...');
    const healthCheck = await makeRequest({
      hostname: 'localhost',
      port: 5000,
      path: '/',
      method: 'GET'
    });
    console.log(`   Status: ${healthCheck.status}`);
    console.log(`   Response: ${JSON.stringify(healthCheck.data)}\n`);

    // Test 2: Get all compliments
    console.log('2. Testing GET /api/compliments...');
    const getCompliments = await makeRequest({
      hostname: 'localhost',
      port: 5000,
      path: '/api/compliments',
      method: 'GET'
    });
    console.log(`   Status: ${getCompliments.status}`);
    console.log(`   Found ${getCompliments.data.count || 0} compliments\n`);

    // Test 3: Create a new compliment
    console.log('3. Testing POST /api/compliments...');
    const newCompliment = {
      name: 'API Test',
      message: 'This is a test compliment from the API test script! 🚀'
    };

    const createCompliment = await makeRequest({
      hostname: 'localhost',
      port: 5000,
      path: '/api/compliments',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    }, newCompliment);

    console.log(`   Status: ${createCompliment.status}`);
    console.log(`   Response: ${JSON.stringify(createCompliment.data, null, 2)}\n`);

    // Test 4: Get compliments again to verify creation
    console.log('4. Verifying compliment was created...');
    const getComplimentsAgain = await makeRequest({
      hostname: 'localhost',
      port: 5000,
      path: '/api/compliments',
      method: 'GET'
    });
    console.log(`   Status: ${getComplimentsAgain.status}`);
    console.log(`   Total compliments: ${getComplimentsAgain.data.count || 0}\n`);

    console.log('✅ All API tests completed successfully!');

  } catch (error) {
    console.error('❌ API test failed:', error.message);
    console.log('\n💡 Make sure the backend server is running on http://localhost:5000');
  }
}

// Run tests
if (require.main === module) {
  testAPI();
}

module.exports = { testAPI };
