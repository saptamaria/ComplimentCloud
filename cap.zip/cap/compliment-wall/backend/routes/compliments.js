const express = require('express');
const router = express.Router();
const Compliment = require('../models/Compliment');

// GET /api/compliments - Get all compliments
router.get('/', async (req, res) => {
  try {
    const compliments = await Compliment.find()
      .sort({ createdAt: -1 }) // Sort by newest first
      .limit(100); // Limit to 100 most recent compliments
    
    res.json({
      success: true,
      count: compliments.length,
      data: compliments
    });
  } catch (error) {
    console.error('Error fetching compliments:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching compliments',
      error: error.message
    });
  }
});

// POST /api/compliments - Create a new compliment
router.post('/', async (req, res) => {
  try {
    const { name, message } = req.body;

    // Validation
    if (!message || message.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Message is required'
      });
    }

    const compliment = new Compliment({
      name: name && name.trim() ? name.trim() : 'Anonymous',
      message: message.trim()
    });

    const savedCompliment = await compliment.save();

    res.status(201).json({
      success: true,
      message: 'Compliment created successfully',
      data: savedCompliment
    });
  } catch (error) {
    console.error('Error creating compliment:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        error: error.message
      });
    }

    res.status(500).json({
      success: false,
      message: 'Error creating compliment',
      error: error.message
    });
  }
});

module.exports = router;
